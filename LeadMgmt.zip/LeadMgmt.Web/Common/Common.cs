﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeadMgmt.Web.Common
{
    enum LeadType
    {
        Business=1,
        Individual=2
    } 
}
